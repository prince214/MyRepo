<?php
header('Content-type: application/json');

// Valiadate & save file on server

// Success 
echo json_encode([ 'error' => 0 ]);

// Error 
//echo json_encode([ 'error' => 1, 'message' => 'An error occurred' ]);

?>