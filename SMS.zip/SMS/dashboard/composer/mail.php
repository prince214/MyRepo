<?php

$servername = "localhost";
$username = "root";
$password = "toor";
$database = "sms";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
else
// echo "connected";



$subject = $_POST['subject'];
$msg = $_POST['Message'];
$teacher_name = $_POST['username'];
$teacher_email = $_POST['username_email'];



$student_sql = "SELECT * FROM students";
$student_result = $conn->query($student_sql);
                     


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;



require_once "vendor/autoload.php";

$mail = new PHPMailer;

//Enable SMTP debugging. 
$mail->SMTPDebug = 3;                               
//Set PHPMailer to use SMTP.
$mail->isSMTP();            
//Set SMTP host name                          
$mail->Host = "	smtp.sendgrid.net";
//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;                          
//Provide username and password     
$mail->Username = "apikey";                 
$mail->Password = "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";                           
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";    //ssl                       
//Set TCP port to connect to 
$mail->Port = 587;   //465              	                  

$mail->From = "kaxopab203@imail8.net";
$mail->FromName = "Prince Paraste";

	// $mail->addAddress("princeparaste78@gmail.com", "Recepient Name");
	 while($row = $student_result->fetch_assoc()) {
	$mail->addAddress($row['email'], "Recepient Name");
	 	// print_r($row);
	}



$mail->isHTML(true);

$mail->Subject = $subject;
$mail->Body = $msg;
$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
} 
else 
{
	echo "send";


	// $test = "SELECT * FROM students";
	// $store = $conn->query($test);


	// while($row = $store->fetch_assoc()) {
		echo "Message has been sent successfully";
			     $store_msg = "INSERT INTO notification (id,teacher_name,teacher_email,message,status)
			     			   VALUES (NULL,'$teacher_name','$teacher_email','$mail->Body','0')";
				 // $store_msg = "UPDATE students SET notification = '$mail->Body' WHERE id={$row['id']}";
				    if($conn->query($store_msg)){
				    	echo"Inserted";
				    }
				    else
				    	echo "error ".$store_msg;
	// }
    
   
}



?>