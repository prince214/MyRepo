<?php
session_start();
include 'connection.php';
$user_id = $_POST['user_id'];

if(isset($_POST['modify'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $sql = "UPDATE teachers SET name='$name',email='$email',password='$pass' WHERE id=$user_id";
    if(mysqli_query($conn,$sql)){
        header("location:../admin.php");
        // echo "got hit111";
    }
    else
    {
        echo "error : ";
        echo $sql;
    }

}

if(isset($_POST['student_modify'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $sql = "UPDATE students SET name='$name',email='$email',password='$pass' WHERE id=$user_id";
    if(mysqli_query($conn,$sql)){
        header("location:../admin.php");
        // echo "got hit111";
    }
    else
    {
        echo "error : ";
        echo $sql;
    }

}

if(isset($_POST['teacher_dashboard_modify'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $sql = "UPDATE students SET name='$name',email='$email',password='$pass' WHERE id=$user_id";
    if(mysqli_query($conn,$sql)){
        header("location:../teacher.php");
        // echo "got hit111";
    }
    else
    {
        echo "error : ";
        echo $sql;
    }

}




    if(isset($_POST['delete'])){
        $user_id2 = $_POST['user_id'];

        $sql = "DELETE FROM teachers WHERE id=$user_id";

      
        $conn->query($sql);

        if($conn){
            header("location:../admin.php");
        }
        else
        {
            echo "error : ";
            echo $sql;
        }
    }

    if(isset($_POST['student_delete'])){
        echo "string";
        $user_id = $_POST['user_id'];
        echo "$user_id2";
        $sql = "DELETE FROM students WHERE id=$user_id";

      
        $conn->query($sql);

        if($conn){
            header("location:../admin.php");
        }
        else
        {
            echo "error : ";
            echo $sql;
        }
    }


    if(isset($_POST['teacher_dashboard_delete'])){
        echo "string";
        $user_id = $_POST['user_id'];
        echo "$user_id2";
        $sql = "DELETE FROM students WHERE id=$user_id";

      
        $conn->query($sql);

        if($conn){
            header("location:../teacher.php");
        }
        else
        {
            echo "error : ";
            echo $sql;
        }
    }

    

    



?>