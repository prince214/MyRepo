<?php 

session_start();
include 'connection.php';

if(isset($_POST['submit'])){

  $email = $_POST['inputEmail'];
  $pass = $_POST['inputPassword'];

  $type = $_POST['selected'];

  $c1 = 'princeparaste78@gmail.com';
  $c2 = '123';


  if($type == "admin"){
		  if($email == $c1 && $pass == $c2){
		      $_SESSION['user']= "I AM GOD";
		      header("location:../admin.php");
		  }
		  else{
		      echo "INVALID CREDENTIALS";
		  }
  }
  if($type == "teacher"){
  		// $email = mysql_real_escape_string($email);
		$sql = "SELECT name FROM teachers WHERE email='$email' AND password='$pass'";
  		$result=mysqli_query($conn,$sql);
  		
  		// print_r($result);
		  if (mysqli_num_rows($result)>0)
		    {
		    	echo "string";
				$value = mysqli_fetch_object($result);
				$_SESSION['user'] = $value->name;
		     header("location:../teacher.php");
		    }
		  else
		  		echo "Teacher not present in the database";

  }

  if($type == "student"){

  	// $email = mysql_real_escape_string($email);
		$sql = "SELECT name FROM students WHERE email='$email' AND password='$pass'";
  		$result=mysqli_query($conn,$sql);
  		
  		// print_r($result);
		  if (mysqli_num_rows($result)>0)
		    {
		    	echo "string";
				$value = mysqli_fetch_object($result);
				$_SESSION['user'] = $value->name;
		     header("location:../student.php");
		    }
		  else
		  		echo "Student not present in the database";

  }






  

}
?> 

