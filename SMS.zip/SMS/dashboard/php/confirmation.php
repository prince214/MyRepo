<?php 

include 'connection.php';






if(isset($_POST['accept'])){
    $teacher_name = $_POST['teacherName-conifrm'];
    $teacher_email = $_POST['teacherEmail-conifrm'];
    $student_name = $_POST['studentName-conifrm'];
    $student_email = $_POST['studentEmail-conifrm'];

    $sql = "INSERT INTO status (id,student_name,student_email,teacher_name,teacher_email,status) 
        VALUE (NULL,'$student_name','$student_email','$teacher_name','$teacher_email','1')";

    if($conn->query($sql)){
      // echo "SUccess";
    	header("location:../student.php");
    }
    else
      echo "fail: ".$sql;

  }

  if(isset($_POST['reject'])){
  	header("location:../student.php");
  }



?>
