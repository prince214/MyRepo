<?php

include 'connection.php';

	if(isset($_POST['add_teacher_record'])){

		$name = $_POST['teacher_name'];
		$email = $_POST['teacher_email'];
		$password = $_POST['teacher_pass'];
		$role = "teacher";

		$sql = "INSERT INTO teachers (id,name,email,password,role) VALUES (NULL,'$name','$email','$password','$role')";

		if($conn ->query($sql)){
			header("Location: ../admin.php");
		}
			
		else
			echo "error: $sql";
	}




	if(isset($_POST['add_student_record'])){

		$name = $_POST['student_name'];
		$email = $_POST['student_email'];
		$password = $_POST['student_pass'];
		$role = "student";

		$sql = "INSERT INTO students (id,name,email,password,role) VALUES (NULL,'$name','$email','$password','$role')";

		if($conn ->query($sql)){
			header("Location: ../admin.php");
		}
		else
			echo "error: $sql";
	}


	if(isset($_POST['rate_done'])){
		echo "string";

		$back_id = $_POST['back_id'];
		$rate = $_POST['selected_rating'];
		$sql_rate = "UPDATE teachers SET rating = '$rate' WHERE id = '$back_id'";
		if($conn->query($sql_rate)){
			echo "success";
		}
		else
			echo "fail";

	}

  


?>