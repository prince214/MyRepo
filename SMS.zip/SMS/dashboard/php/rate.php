<?php
session_start();
include 'connection.php';

if(isset($_POST['TEST'])){

		$teacher_id = $_POST['teacher_id'];
		$student_id = $_POST['student_id'];
		$rate = $_POST['selected_rating'];



		$fetch_student = "SELECT name,email FROM students WHERE id = '$student_id'";
		$student_data = mysqli_fetch_object($conn->query($fetch_student));
		$student_name = $student_data->name;
		$student_email = $student_data->email;

		$fetch_teacher = "SELECT name,email FROM teachers WHERE id = '$teacher_id'";
		$teacher_data= mysqli_fetch_object($conn->query($fetch_teacher));
		$teacher_name = $teacher_data->name;
		$teacher_email = $teacher_data->email;

		echo $sql_rate = "INSERT INTO ratings (id,student_name,student_email,teacher_name,teacher_email,teacher_rating)
			     VALUES (NULL,'$student_name','$student_email','$teacher_name','$teacher_email','$rate')";
		// // $sql_rate = "UPDATE teachers SET rating = '$rate' WHERE id = '$student_id'";
		if($conn->query($sql_rate)){
			echo "success";
		}
		else
			echo "fail";

	}


?>