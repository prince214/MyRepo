---
name: "\U0001F46E‍♂️Security issue"
about: Please report security issues *only* via https://ultimatemember.com/feedback/
title: ''
labels: ''
assignees: ''

---

For security reasons, please report all security issues via https://ultimatemember.com/feedback/.  

Please disclose responsibly and not via GitHub (which allows for exploiting issues in the wild before the patch is released).