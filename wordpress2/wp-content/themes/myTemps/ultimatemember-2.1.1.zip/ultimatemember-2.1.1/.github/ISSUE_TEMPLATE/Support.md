---
name: "❓ Support Question"
about: "If you have a question \U0001F4AC please see our docs or use our forums & support page"
title: ''
labels: ''
assignees: ''

---

We don't offer technical support on GitHub so we recommend using the following:

**Reading our documentation**
Usage docs can be found here: https://docs.ultimatemember.com

If you have a problem, you may want to start with the self help guide here: https://docs.ultimatemember.com/article/1507-ultimate-member-self-service-guide/

**Technical support for premium extensions or if you're a UltimateMember.com customer**
Please submit a ticket via the support page
https://ultimatemember.com/support/ticket/

**General questions**
- WordPress.org Forums: https://wordpress.org/support/plugin/ultimate-member/
